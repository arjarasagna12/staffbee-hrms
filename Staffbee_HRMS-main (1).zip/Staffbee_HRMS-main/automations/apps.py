"""
App configuration for the Staffbee Automations app.
Initializes model choices and starts automation when the server runs.
"""

import os
import sys

from django.apps import AppConfig


class StaffbeeAutomationConfig(AppConfig):
    """Configuration class for the Staffbee Automations Django app."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "automations"

    def ready(self):
        """Run initialization tasks when the app is ready."""
        from base.templatetags.staffbeefilters import app_installed
        from employee.models import Employee
        from automations.methods.methods import get_related_models
        from automations.models import MODEL_CHOICES as model_choices

        # Build MODEL_CHOICES
        models = [Employee]
        if app_installed("recruitment"):
            from recruitment.models import Candidate

            models.append(Candidate)

        for main_model in models:
            for model in get_related_models(main_model):
                model_choices.append(
                    (f"{model.__module__}.{model.__name__}", model.__name__)
                )

        model_choices.append(("employee.models.Employee", "Employee"))
        model_choices.append(("pms.models.EmployeeKeyResult", "Employee Key Results"))
        model_choices[:] = list(set(model_choices))  # Update in-place

        # Only start automation when running the server
        if not any(
            cmd in sys.argv
            for cmd in [
                "makemigrations",
                "migrate",
                "compilemessages",
                "flush",
                "shell",
            ]
        ):
            from automations.signals import start_automation

            start_automation()
