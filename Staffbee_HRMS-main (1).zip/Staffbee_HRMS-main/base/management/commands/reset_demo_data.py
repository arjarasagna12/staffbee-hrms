"""
Staffbee management command to reset database to demo data while preserving admin user.
"""

import os
from django.conf import settings
from django.contrib.auth.models import User
from django.core.management import call_command
from django.core.management.base import BaseCommand
from django.apps import apps

from employee.models import Employee


class Command(BaseCommand):
    """
    Reset database to demo data while preserving the admin user created during initialization.
    """

    help = "Resets database to demo data while preserving admin user"

    def handle(self, *args, **options):
        self.stdout.write(
            self.style.WARNING("Starting database reset to demo data...")
        )

        # Step 1: Identify and store admin user data
        admin_user = None
        admin_employee = None

        superusers = User.objects.filter(is_superuser=True)
        for user in superusers:
            if hasattr(user, "employee_get"):
                admin_user = user
                admin_employee = user.employee_get
                break

        if not admin_user:
            self.stdout.write(
                self.style.ERROR(
                    "No admin user found with associated employee. "
                    "Please run database initialization first."
                )
            )
            return

        # Store admin user data
        admin_data = {
            "username": admin_user.username,
            "email": admin_user.email,
            "password": admin_user.password,  # Already hashed
            "first_name": admin_user.first_name,
            "last_name": admin_user.last_name,
            "is_staff": admin_user.is_staff,
            "is_active": admin_user.is_active,
            "is_superuser": admin_user.is_superuser,
            "date_joined": admin_user.date_joined,
        }

        # Store admin employee data
        employee_data = {
            "badge_id": admin_employee.badge_id,
            "employee_first_name": admin_employee.employee_first_name,
            "employee_last_name": admin_employee.employee_last_name,
            "email": admin_employee.email,
            "phone": admin_employee.phone,
        }

        self.stdout.write(
            self.style.SUCCESS(
                f'Preserved admin user: {admin_user.username} ({admin_user.email})'
            )
        )

        # Step 2: Delete all data using raw SQL to handle foreign keys
        self.stdout.write(self.style.WARNING("Clearing database..."))

        from django.db import connection

        with connection.cursor() as cursor:
            # Disable foreign key checks temporarily
            cursor.execute("SET session_replication_role = 'replica';")

            # Get all table names except django migrations and content types
            cursor.execute("""
                SELECT tablename FROM pg_tables
                WHERE schemaname = 'public'
                AND tablename NOT LIKE 'django_migrations'
                AND tablename NOT IN ('django_content_type', 'auth_permission')
            """)
            tables = cursor.fetchall()

            # Truncate all tables except critical system tables
            for table in tables:
                try:
                    cursor.execute(f'TRUNCATE TABLE "{table[0]}" RESTART IDENTITY CASCADE;')
                    self.stdout.write(f"Cleared: {table[0]}")
                except Exception as e:
                    self.stdout.write(
                        self.style.WARNING(f"Could not clear {table[0]}: {e}")
                    )

            # Re-enable foreign key checks
            cursor.execute("SET session_replication_role = 'origin';")

        # Recreate content types for all installed models
        self.stdout.write(self.style.WARNING("Updating content types..."))
        from django.contrib.contenttypes.management import create_contenttypes
        from django.apps import apps as django_apps

        for app_config in django_apps.get_app_configs():
            create_contenttypes(app_config)

        # Step 3: Load demo data in correct dependency order
        self.stdout.write(self.style.WARNING("Loading demo data..."))

        # Core data files in correct dependency order
        # Note: Order is critical due to foreign key constraints
        core_data_files = [
            "user_data.json",            # Users (must be first - referenced by base_data)
            "base_data.json",            # Companies, departments, positions, etc. (references users)
            "employee_info_data.json",   # Employees (depends on users and companies)
            "work_info_data.json",       # Work info (depends on employees and base_data)
        ]

        # Independent/utility data files (no specific dependencies)
        utility_data_files = [
            "tags.json",
            "faq_category.json",
            "faq.json",
            "mail_templates.json",
            "mail_automations.json",
        ]

        # Optional module data files
        optional_apps = [
            ("attendance", "attendance_data.json"),
            ("leave", "leave_data.json"),
            ("asset", "asset_data.json"),
            ("recruitment", "recruitment_data.json"),
            ("onboarding", "onboarding_data.json"),
            ("offboarding", "offboarding_data.json"),
            ("pms", "pms_data.json"),
            ("payroll", "payroll_data.json"),
            ("payroll", "payroll_loanaccount_data.json"),
            ("project", "project_data.json"),
        ]

        # Load core data files first (Pass 1)
        for file in core_data_files:
            file_path = os.path.join(settings.BASE_DIR, "load_data", file)
            try:
                call_command("loaddata", file_path)
                self.stdout.write(
                    self.style.SUCCESS(f"✓ Loaded: {file}")
                )
            except Exception as e:
                self.stdout.write(
                    self.style.ERROR(f"✗ Error loading {file}: {e}")
                )
                # For base_data, try to continue despite errors as some records may succeed
                if file == "base_data.json":
                    self.stdout.write(
                        self.style.WARNING(
                            "  → Continuing despite base_data errors (some records may have loaded)"
                        )
                    )

        # Reload base_data to catch employee assignments that failed initially (Pass 2)
        self.stdout.write(
            self.style.WARNING(
                "\nReloading base_data to load employee assignments..."
            )
        )
        try:
            file_path = os.path.join(settings.BASE_DIR, "load_data", "base_data.json")
            call_command("loaddata", file_path)
            self.stdout.write(
                self.style.SUCCESS("✓ Successfully loaded remaining base_data records")
            )
        except Exception as e:
            self.stdout.write(
                self.style.WARNING(f"⚠ Some base_data records still couldn't load: {e}")
            )

        # Reload work_info_data to catch records that failed due to missing companies (Pass 2)
        self.stdout.write(
            self.style.WARNING(
                "Reloading work_info_data to catch records with foreign key dependencies..."
            )
        )
        try:
            file_path = os.path.join(settings.BASE_DIR, "load_data", "work_info_data.json")
            if os.path.exists(file_path):
                call_command("loaddata", file_path)
                self.stdout.write(
                    self.style.SUCCESS("✓ Successfully loaded remaining work_info_data records")
                )
        except Exception as e:
            self.stdout.write(
                self.style.WARNING(f"⚠ Some work_info_data records still couldn't load: {e}")
            )

        # Load utility data files
        self.stdout.write(self.style.WARNING("\nLoading utility data files..."))
        for file in utility_data_files:
            file_path = os.path.join(settings.BASE_DIR, "load_data", file)
            if os.path.exists(file_path):
                try:
                    call_command("loaddata", file_path)
                    self.stdout.write(
                        self.style.SUCCESS(f"✓ Loaded: {file}")
                    )
                except Exception as e:
                    self.stdout.write(
                        self.style.WARNING(f"⚠ Skipped {file}: {e}")
                    )

        # Load optional module data files (Pass 1)
        self.stdout.write(self.style.WARNING("\nLoading optional module data..."))
        for app, file in optional_apps:
            if apps.is_installed(app):
                file_path = os.path.join(settings.BASE_DIR, "load_data", file)
                try:
                    call_command("loaddata", file_path)
                    self.stdout.write(
                        self.style.SUCCESS(f"✓ Loaded: {file}")
                    )
                except Exception as e:
                    self.stdout.write(
                        self.style.WARNING(f"⚠ Skipped {file}: {e}")
                    )

        # Second pass for optional module data to catch foreign key dependencies (Pass 2)
        self.stdout.write(
            self.style.WARNING(
                "\nReloading optional module data for foreign key dependencies..."
            )
        )
        for app, file in optional_apps:
            if apps.is_installed(app):
                file_path = os.path.join(settings.BASE_DIR, "load_data", file)
                try:
                    call_command("loaddata", file_path)
                    self.stdout.write(
                        self.style.SUCCESS(f"✓ Reloaded: {file}")
                    )
                except Exception as e:
                    self.stdout.write(
                        self.style.WARNING(f"⚠ Skipped {file} (Pass 2): {e}")
                    )

        # Step 4: Restore admin user credentials
        self.stdout.write(self.style.WARNING("\nRestoring admin user credentials..."))

        # Check if demo data has a user with the same username or email
        demo_user = User.objects.filter(username=admin_data["username"]).first()
        if not demo_user:
            demo_user = User.objects.filter(email=admin_data["email"]).first()

        if demo_user:
            # Update existing demo user with admin credentials
            self.stdout.write(
                f"  → Found existing user '{demo_user.username}', updating credentials..."
            )
            demo_user.username = admin_data["username"]
            # Keep email from JSON - don't overwrite with old email
            demo_user.password = admin_data["password"]  # Restore original password
            demo_user.is_superuser = True
            demo_user.is_staff = True
            demo_user.is_active = True
            demo_user.save()

            # Update associated employee record
            if hasattr(demo_user, "employee_get"):
                demo_employee = demo_user.employee_get
                demo_employee.badge_id = employee_data["badge_id"]
                demo_employee.employee_first_name = employee_data["employee_first_name"]
                demo_employee.employee_last_name = employee_data["employee_last_name"]
                # Keep email from JSON - don't overwrite with old email
                if employee_data["phone"]:
                    demo_employee.phone = employee_data["phone"]
                demo_employee.save()
                self.stdout.write(
                    self.style.SUCCESS(
                        f"  ✓ Updated existing user and employee with admin credentials"
                    )
                )
            else:
                # Create employee for existing user
                restored_employee = Employee()
                restored_employee.employee_user_id = demo_user
                restored_employee.badge_id = employee_data["badge_id"]
                restored_employee.employee_first_name = employee_data["employee_first_name"]
                restored_employee.employee_last_name = employee_data["employee_last_name"]
                # Email should come from JSON data, not old preserved data
                restored_employee.phone = employee_data["phone"]
                restored_employee.save()
                self.stdout.write(
                    self.style.SUCCESS(
                        f"  ✓ Updated user and created employee record"
                    )
                )
        else:
            # No conflict - create new admin user and employee
            # This should rarely happen since admin typically exists in demo data
            self.stdout.write("  → No conflicting user found, creating new admin...")

            # Step 5: Create admin user and employee with preserved credentials
            # but use demo email if available
            restored_user = User(
                username=admin_data["username"],
                email=admin_data["email"],  # Use old email as fallback since no demo user exists
                first_name=admin_data["first_name"],
                last_name=admin_data["last_name"],
                is_staff=admin_data["is_staff"],
                is_active=admin_data["is_active"],
                is_superuser=admin_data["is_superuser"],
                date_joined=admin_data["date_joined"],
            )
            restored_user.password = admin_data["password"]  # Set pre-hashed password
            restored_user.save()

            # Create employee
            restored_employee = Employee()
            restored_employee.employee_user_id = restored_user
            restored_employee.badge_id = employee_data["badge_id"]
            restored_employee.employee_first_name = employee_data["employee_first_name"]
            restored_employee.employee_last_name = employee_data["employee_last_name"]
            restored_employee.email = employee_data["email"]  # Use old email as fallback
            restored_employee.phone = employee_data["phone"]
            restored_employee.save()
            self.stdout.write(
                self.style.SUCCESS(
                    f"  ✓ Created new admin user and employee"
                )
            )

        # Final success message
        self.stdout.write(
            self.style.SUCCESS(
                f'\n{"="*60}\nDatabase reset completed successfully!\n{"="*60}'
            )
        )
        self.stdout.write(
            self.style.SUCCESS(
                f'Admin user "{admin_data["username"]}" has been preserved.'
            )
        )
        self.stdout.write(
            self.style.SUCCESS(
                'You can now login with your original credentials.\n'
            )
        )
