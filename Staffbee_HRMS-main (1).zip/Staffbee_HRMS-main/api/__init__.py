from staffbee.settings import INSTALLED_APPS

INSTALLED_APPS.append("geofencing")
INSTALLED_APPS.append("facedetection")
