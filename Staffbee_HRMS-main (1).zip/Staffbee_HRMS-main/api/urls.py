from django.urls import include, path

urlpatterns = [
    path("auth/", include("api.api_urls.auth.urls")),
    path("asset/", include("api.api_urls.asset.urls")),
    path("base/", include("api.api_urls.base.urls")),
    path("employee/", include("api.api_urls.employee.urls")),
    path("notifications/", include("api.api_urls.notifications.urls")),
    path("payroll/", include("api.api_urls.payroll.urls")),
    path("attendance/", include("api.api_urls.attendance.urls")),
    path("leave/", include("api.api_urls.leave.urls")),
]
