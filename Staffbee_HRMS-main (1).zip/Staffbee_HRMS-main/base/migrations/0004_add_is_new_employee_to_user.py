# Generated migration to add is_new_employee field to User model
from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('base', '0003_rename_horillamailtemplate_staffbeemailtemplate_and_more'),
        ('auth', '0012_alter_user_first_name_max_length'),  # Django's latest auth migration
    ]

    operations = [
        migrations.RunSQL(
            # Add the column if it doesn't exist
            sql="""
            DO $$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1 FROM information_schema.columns
                    WHERE table_name='auth_user' AND column_name='is_new_employee'
                ) THEN
                    ALTER TABLE auth_user ADD COLUMN is_new_employee BOOLEAN DEFAULT FALSE NOT NULL;
                END IF;
            END $$;
            """,
            # Reverse migration - drop the column
            reverse_sql="""
            ALTER TABLE auth_user DROP COLUMN IF EXISTS is_new_employee;
            """
        ),
    ]
