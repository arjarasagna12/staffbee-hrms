"""
biometric app

This app contains modules for handling biometric devices.
"""

from . import settings
