"""
automations/filters.py
"""

from staffbee.filters import StaffbeeFilterSet, django_filters
from automations.models import MailAutomation


class AutomationFilter(StaffbeeFilterSet):
    """
    AutomationFilter
    """

    search = django_filters.CharFilter(field_name="title", lookup_expr="icontains")

    class Meta:
        model = MailAutomation
        fields = "__all__"
